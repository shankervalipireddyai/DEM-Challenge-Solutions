#ML Model Deployment:

This project demonstrates the usage of AWS lambda and ECR  with API gateway to deploy ML model which has been trained on IRIS dataset. 
